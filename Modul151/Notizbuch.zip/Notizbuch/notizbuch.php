<?php
//Einbinden des Datenbankscripts
include('php/database_setup.inc.php');

//Config-Datei einbinden
$config = parse_ini_file("cfg/config.ini");

//Datenbankverbindung
$mysqli = new mysqli($config['host'], $config['username'], $config['password'], $config['db_name']);

//Session starten
session_start();

//Überprüfen ob Logout
if (isset($_GET['logout'])) {
	session_destroy();
	header("Location: index.php");
}

//Notiz erstellen
if (isset($_GET['create'])) {
	$sql = "INSERT INTO notes (note, user, userid)
	VALUES ('" . $_POST['note'] . "', '" . $_POST['user'] . "', '" . $_SESSION['userid'] . "')";
	$mysqli->query($sql);
	header("Location: notizbuch.php");
}

//Notiz abspeichern
if (isset($_GET['update'])) {
	$sql = "UPDATE notes SET note='" . $_POST['note'] . "' WHERE id=" . $_POST['id'] . "";
	$mysqli->query($sql);
	header("Location: notizbuch.php");
}

//Passwort ändern
if (isset($_GET['updatePassword'])) {
	if ($_POST['password'] == $_POST['password1']) {
		$passwordHash = password_hash($_POST['password'], PASSWORD_DEFAULT);
		$sql = "UPDATE users SET password='" . $passwordHash . "' WHERE id=" . $_SESSION['userid'] . "";
		$mysqli->query($sql);
		header("Location:notizbuch.php");
	}
}

//Notiz löschen
if (isset($_GET['delete'])) {
	$sql = "DELETE FROM notes WHERE id=" . $_POST['id'] . "";
	$mysqli->query($sql);
	header("Location: notizbuch.php");
}

//Überprüfen ob User-ID vorhanden
if (isset($_SESSION['userid'])) {
?>
	<!DOCTYPE html>
	<html lang="de">

	<head>
		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1" name="viewport" />
		<script src="js/links.js"></script>
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<script src="https://kit.fontawesome.com/a96c0df94b.js" crossorigin="anonymous"></script>
	</head>

	<body>
		<div class="columnBox">
			<div class="height-100">
				<header>
					<div class="rowBox">
						<form method="post" action="?logout=1">
							<div>
								<nav>
									<ul>
										<li>
											<button type="submit">Ausloggen</button>
										</li>
										<li>
											<button type="button" onclick="create()">Erstellen</button>
										</li>
										<li>
											<button type="button" onclick="changePassword()">Passwort ändern</button>
										</li>
									</ul>
								</nav>
							</div>
						</form>
						<div id="creator">
							<h3>&copy;Aleksandar Stojakovic</h3>
						</div>
					</div>
				</header>
			</div>
			<div class="display-grid">
				<?php
				$sql = "SELECT * FROM notes";
				$result = $mysqli->query($sql);

				while ($note = $result->fetch_assoc()) {
				?>
					<!-- Ersteller von der Notiz und die Notiz -->
					<div class="columnBox note-content">
						<div style="display: flex; flex-direction: row; justify-content: space-between;">
							<div>
								<form action="?update=1" method="post">
									<div>
										Ersteller: <br><?php echo $note['user']; ?>
									</div>
									<div>
										Notiz <br><input style="display: none;" type="text" name="id" value="<?php echo $note['id']; ?>">
										<div style="display: flex; flex-direction: row;">
											<div><textarea disabled="true" type="text" name="note" id="edit<?php echo $note['id']; ?>"><?php echo $note['note']; ?></textarea></div>
											<div><button type="submit" id="save<?php echo $note['id']; ?>" style="display: none; color: #99eb6a;"><i class="fas fa-check-circle"></i></button></div>
										</div>
									</div>
								</form>
							</div>
							<div style="display: flex; flex-direction: column; justify-content: space-between;">
								<div>
									<button type="button" onclick="edit(<?php echo $note['id']; ?>)"><i class="fas fa-edit fa-2x"></i></button>
								</div>

								<form action="?delete=1" method="post">
									<div>
										<input style="display: none;" type="text" name="id" value="<?php echo $note['id'] ?>">
										<button type="submit"><i class="fas fa-trash fa-2x"></i></button>
									</div>
								</form>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
		<div id="infobox" class="infoBox">
			<form method="post" action="?create=1">
				<div style="display: flex; flex-direction: column;">
					<div style="display: flex; flex-direction: row; justify-content: space-between;">
						<div>
							<label>Benutzer</label>
						</div>
						<div>
							<input type="text" name="user" value="<?php echo $_SESSION['username']; ?>"><br>
						</div>
					</div>
					<div style="display: flex; flex-direction: row; justify-content: space-between;">
						<div>
							<label>Notiz</label>
						</div>
						<div>
							<input type="text" name="note">
						</div>
			</form>
		</div>
		<div>
			<button type="submit">Speichern</button>
		</div>
		</div>
		</div>
		<div id="passwordform">
			<form action="?updatePassword=1" method="post">
				<div class="columnBox">
					<div class="columnBox">
						<div><label>Neues Passwort</label></div>
						<div><input type="password" name="password"></div>
					</div>
					<div class="columnBox">
						<div><label>Passwort bestätigen</label></div>
						<div><input type="password" name="password1"></div>
					</div>
					<div>
						<button type="submit">Abspeichern</button>
					</div>



				</div>
			</form>
		</div>
		<script>
			function create() {
				document.getElementById("infobox").style.display = "block";
			}

			function edit(id) {
				document.getElementById("edit" + id).removeAttribute("disabled");
				document.getElementById("save" + id).style.display = "block";
			}

			function changePassword() {
				document.getElementById("passwordform").style.display = "block";

			}
		</script>
	</body>
<?php
} else {
	header("Location: index.php");
}
?>

	</html>