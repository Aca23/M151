<?php
//Config-Datei einbinden
$config = parse_ini_file("cfg/config.ini");

//Session starten
session_start();

//Session ID verändern
session_regenerate_id(true);

//Datenbankverbindung
$mysqli = new mysqli($config['host'], $config['username'], $config['password'], $config['db_name']);

$error = '';
$message = '';

$username = '';
$password = '';



//Login
if (isset($_GET['login'])) {
	$username = $_POST['username'];
	$stmt = "SELECT * FROM users WHERE username = '" . $username . "'";
	$query = mysqli_query($mysqli, $stmt);
	if (mysqli_num_rows($query) != 0) {
		while ($user = mysqli_fetch_array($query, MYSQLI_ASSOC)) {
			if (password_verify($_POST['password'], $user['password'])) {
				$_SESSION['userid'] = $user['id'];
				$_SESSION['username'] = $user['username'];
				header("Location: notizbuch.php");
			} else {
				echo "<div class='errormessage'>Benutzername oder Passwort sind falsch</div>";
			}
		}
	} else {
		echo "<div class='errormessage'>Benutzername oder Passwort sind falsch</div>";
	}
}

//Registrieren
if (isset($_GET['register'])) {
	if ($_POST['password'] == $_POST['password1']) {
		$passwordHash = password_hash($_POST['password'], PASSWORD_DEFAULT);

		$firstname = $_POST['firstname'];
		$lastname = $_POST['lastname'];
		$username = $firstname . "." . $lastname;

		$stmt = mysqli_prepare($mysqli, "INSERT INTO users (firstname, lastname, username, password)
		VALUES (?, ?, ?, ?)");
		mysqli_stmt_bind_param($stmt, 'ssss', $firstname, $lastname, $username, $passwordHash);
		mysqli_stmt_execute($stmt);
		header("Location:login.php");
	} else {
		echo "<script>alert('Passwörter nicht identisch!');</script>";
	}
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Registrierung</title>

	<link rel="stylesheet" href="css/style.css">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

	<script src="js/animations.js"></script>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body style="background-image: unset;">
	<div class="login-reg-panel">
		<div class="login-info-box">
			<h2>Account bereits vorhanden?</h2>
			<p>Zögern Sie nicht sich einzuloggen</p>
			<button class="button" onclick="loginShow()">Einloggen</button>
		</div>

		<div class="register-info-box">
			<h2>Noch kein Account vorhanden?</h2>
			<p>Zögern Sie nicht sich zu registrieren</p>
			<button class="button" onclick="registerShow()">Registrieren</button><br><br>
			<h4><?php echo $message; ?></h4>
		</div>

		<div class="white-panel">
			<div class="login-show">
				<h2>LOGIN</h2>
				<form action="?login=1" method="post">
					<input name="username" type="text" placeholder="Benutzername" required>
					<input name="password" type="password" placeholder="Passwort" required>
					<input class="submit" type="submit" value="Login">
				</form>
			</div>
			<div class="register-show">
				<h2>REGISTRIEREN</h2>
				<form action="?register=1" method="post">
					<input name="firstname" type="text" placeholder="Vorname" required>
					<input name="lastname" type="text" placeholder="Nachname" required>
					<input name="password" type="password" placeholder="Passwort" required>
					<input name="password1" type="password" placeholder="Passwort erneut eingeben" required>
					<input class="submit" type="submit" value="Register">
				</form>
			</div>
		</div>
	</div>
</body>

</html>