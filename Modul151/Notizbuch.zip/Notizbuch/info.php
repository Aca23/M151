<?php
session_start();
?>
<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<script src="js/links.js"></script>
    <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body style="background-image: unset;">

<script>

  </script>
</body>
</html>