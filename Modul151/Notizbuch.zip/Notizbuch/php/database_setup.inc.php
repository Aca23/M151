<?php
$config = parse_ini_file("cfg/config.ini");

$host = $config['host']; // host

$username = $config['username']; // username

$password = $config['password']; // password

$database = $config['db_name']; // database

$conn = mysqli_connect($host, $username, $password);

//Neue Datenbank anlegen
$create = "CREATE DATABASE Notizbuch";
mysqli_query($conn, $create);

// mit Datenbank verbinden
$mysqli = new mysqli($host, $username, $password, $database);

// fehlermeldung, falls verbindung fehl schlägt.
if ($mysqli->connect_error) {

    die('Connect Error (' . $mysqli->connect_errno . ') '. $mysqli->connect_error);

}

//Tabellen anlegen
$users = "CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

$notes = "CREATE TABLE `notes` (
  `id` bigint(20) NOT NULL,
  `note` TEXT NOT NULL,
  `user` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

mysqli_query($mysqli, $users);
mysqli_query($mysqli, $notes);

mysqli_close($mysqli);

?>