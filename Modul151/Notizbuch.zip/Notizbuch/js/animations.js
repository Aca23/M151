
    $(document).ready(function(){
    $('.login-show').addClass('show-log-panel');
});


function registerShow(){
	var register = document.getElementsByClassName('register-show');
	register[0].style.display = "block";
	
	var registerInfo = document.getElementsByClassName('register-info-box');
	registerInfo[0].style.display = "none";
	
	var login = document.getElementsByClassName('login-show');
	login[0].style.display = "none";
	
	var loginInfo = document.getElementsByClassName('login-info-box');
	loginInfo[0].style.display = "block";
	
}

function loginShow(){
	var login = document.getElementsByClassName('login-show');
	login[0].style.display = "block";
	
	var loginInfo = document.getElementsByClassName('login-info-box');
	loginInfo[0].style.display = "none";
	
	var register = document.getElementsByClassName('register-show');
	register[0].style.display = "none";
	
	var registerInfo = document.getElementsByClassName('register-info-box');
	registerInfo[0].style.display = "block";
	
}