function login(){
	window.location.assign("login.php");
}