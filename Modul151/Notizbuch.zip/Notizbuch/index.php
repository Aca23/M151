<?php
//Einbinden des Datenbankscripts
include('php/database_setup.inc.php');

//Session starten
session_start();

//Überprüfen ob Session-ID vorhanden
if(isset($_SESSION['userid'])){
	header("Location: notizbuch.php");
}else{
?>
<!DOCTYPE html>
<html lang="de">
<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<script src="js/links.js"></script>
    <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<header>
<div class="rowBox">
<div>
	<nav>
	<ul>
		<li>
		<button onclick="login()">Registrieren | Einloggen</button>
		</li>
	</ul>
	</nav>
</div>
<div id="creator">
	<h3>&copy;Aleksandar Stojakovic</h3>
</div>
</div>
</header>
<div id="introduction">
<h2>Willkommen</h2>
Dies ist mein erstes Notizbuch
</div>
</body>
<?php } ?>
</html>